package main

import (
	"github.com/GoToolSharing/htb-cli/cmd"
)

func main() {
	cmd.Execute()
}
